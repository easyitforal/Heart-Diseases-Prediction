

class Process:

    def predict(counter):
        
        if(counter>0 and counter==1):
            stag='Stage 1'
            pred='Heart Failure'

        elif(counter >0 and counter<300):
            stag='Stage 2'
            pred='Heart Failure'

        
        elif(counter >300 and counter<600):
            stag='Stage 3'
            pred='Heart Failure'
        
        
        elif(counter >600):
            stag='Stage 4'
            pred='Heart Failure'

        else:
            stag='Normal'
            pred='Normal'

        return stag,pred
