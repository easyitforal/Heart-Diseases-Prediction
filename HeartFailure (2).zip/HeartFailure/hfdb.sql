-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2020 at 03:25 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hfdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `hfdataset`
--

CREATE TABLE `hfdataset` (
  `Pid` varchar(255) NOT NULL,
  `Pname` varchar(255) NOT NULL,
  `Age` varchar(255) NOT NULL,
  `Date` varchar(255) NOT NULL,
  `Doctor` varchar(255) NOT NULL,
  `Gender` varchar(255) NOT NULL,
  `Symptoms1` varchar(1000) NOT NULL,
  `Symptoms2` varchar(1000) NOT NULL,
  `Addiction` varchar(1000) NOT NULL,
  `Stage` varchar(255) NOT NULL,
  `Operation` varchar(255) NOT NULL,
  `Diagsymptoms` varchar(1000) NOT NULL,
  `Prediction` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hfdataset`
--

INSERT INTO `hfdataset` (`Pid`, `Pname`, `Age`, `Date`, `Doctor`, `Gender`, `Symptoms1`, `Symptoms2`, `Addiction`, `Stage`, `Operation`, `Diagsymptoms`, `Prediction`) VALUES
('22', 'q', 'w', '', 'w', '', 'w', 'w', 'w', 'Normal', 'w', 'w', 'Normal'),
('P999', 'Sanjay', '40', '4/7/2019', 'Manith221', 'Male', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Alchoholic', 'hypertension, diabities', 'Stage 2', 'Surgery', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Normal'),
('Pat101', 'Mamatha', '40', '43468', 'Dr. Neha', 'Male', '', 'smoking, poor nutrition', 'diabties, anemia', 'Stage 1', 'Surgery', 'pain in bones or joints, dizziness, fatigue, fever, loss of appetite, Fatigue, Fever, Bruising, Frequent infections, Limb pain, Stomach pain', 'Heart Attack'),
('Pat102', 'Raghav', '33', '43498', 'Dr. Sashwath', 'Male', '', 'smoking, alcohol, chewing tobacco', 'hypertension, hepatits', 'Stage 3', 'Chemotheraphy', 'red spots on skin, shortness of breath, pain in bones or joints,Fatigue, Fever, Bruising, Frequent infections, Limb pain, Stomach pain', 'Heart Attack'),
('Pat103', 'Vedhya', '33', '43254', 'Dr. Pranesh', 'Male', '', 'smoking, alcohol, chewing tobacco, poor nutrition', 'pneumonia,hypertension', 'Stage 4', 'Chemotheraphy', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Fever, Bruising, Frequent infections, Limb pain, Stomach pain', 'Heart Attack'),
('Pat104', 'chinthana', '54', '43319', 'Dr. Sunil', 'Female', '', 'chewing tobacco, weakened immune system, poor nutrition', 'heart related problem, hypertension', 'Stage 2', 'Radiation Theraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Fever, Bruising, Frequent infections, Limb pain, Stomach pain', 'Heart Attack'),
('Pat105', 'Aakruth', '48', '43511', 'Dr. Vinay', 'Male', '', 'smoking, comsuming alcohol, hpv infection, genetic syndrome', 'diabities', 'Stage 4', 'Chemotheraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Fever, Bruising, Frequent infections, Limb pain, Stomach pain', 'Heart Attack'),
('Pat106', 'Shanthi', '50', '43490', 'Dr. Smitha', 'Female', '', 'weakened immune system, poor nutrition', 'hypertension', 'Stage 1', 'Surgery', 'pain in bones or joints, Fatigue, Fever, Bruising, Frequent infections, Limb pain, Stomach pain', 'Heart Attack'),
('Pat107', 'Sumithra', '90', '43522', 'Dr. Krishna', 'Female', '', 'chewing tobacco, weakened immune system, poor nutrition, genetic syndrome', 'anemia', 'Stage 3', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymph,Fatigue, Fever, Bruising, Frequent infections, Limb pain, Stomach pain', 'Heart Attack'),
('Pat108', 'Prabha', '49', '43495', 'Dr. Archana', 'Male', '', 'chewing tobacco, weakened immune system, smoking, consuming alcohol', 'obesity', 'Stage 4', 'Chemotheraphy', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Fever, Bruising, Frequent infections, Limb pain, Stomach pain', 'Heart Attack'),
('Pat109', 'Madhu', '69', '43524', 'Dr. Vijay', 'Male', '', 'smoking, hpv infection, genetic syndrome', 'chronic bronchitis', 'Stage 3', 'Chemotheraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Fever, Bruising, Frequent infections, Limb pain, Stomach pain', 'Heart Attack'),
('Pat110', 'Prasad', '65', '43527', 'Dr. Roopa', 'Male', '', 'alcohol, poor nutrition,chronic facial sun exposure', 'hypertension, diabities', 'Stage 2', 'Radiation Theraphy', 'weight loss, frequent infections, easy bleeding,Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat111', 'Akshith', '18', '43560', 'Dr. Akash', 'Male', '', 'alcohol, hpv infection, poor nutrition', 'anemia, obesity', 'Stage 2', 'Radiation Theraphy', 'pain in bones or joints, red spots on skin, shortness of breath,Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat112', 'Amrutha', '68', '43561', 'Dr. Yogesh', 'Female', '', 'hpv infection, poor nutrtion', 'pneumonia,diabities', 'Stage 1', 'hypertension, diabities', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat113', 'Amulya', '88', '43558', 'Dr. Harish', 'Male', '', 'smoking, consuming alcohol, genetic syndrome, ÿhpv infection', 'heart related problem, hypertension', 'Stage 4', 'Chemotheraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat114', 'Anjana', '60', '43521', 'Dr. Anand', 'Female', '', 'chewing tobacco, hpv infection, chronic facial sun exposure', 'pneumonia', 'Stage 3', 'Chemotheraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat115', 'Ankitha', '26', '43530', 'Dr. Amrutha', 'Male', '', 'smoking', 'chronic bronchitis, obesity', 'Stage 1', 'Chemotheraphy', 'pain in bones or joints, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat116', 'Annapurna', '56', '43499', 'Dr. Venkatesh', 'Female', '', 'chewing tobacco, poor nutrition, genetic syndrome', 'obesity,anemia, diabities', 'Stage 2', 'Radiation Theraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat117', 'Archana', '79', '43469', 'Dr. Sowmya', 'Male', '', 'chewing tobacco, weakened immune system, smoking, consuming alcohol, genetic syndrome', 'hypertension', 'Stage 4', 'Chemotheraphy', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat118', 'Arpitha', '40', '43496', 'Dr. Veena', 'Male', '', 'consuming alcohol, smoking, hpv infection, genetic syndrome, chronic facial sun exposure', 'obesity', 'Stage 4', 'Chemotheraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat119', 'Arun', '10', '43491', 'Dr. Suresh', 'Male', '', 'smoking, consuming alcohol, hpv infection', 'anemia, pneumonia', 'Stage 2', 'Radiation Theraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat120', 'Asha', '84', '43510', 'Dr. Ramesh', 'Female', '', 'chewing tobacco', 'diabities', 'Stage 1', 'Surgery', 'pain in bones or joints, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Normal'),
('Pat121', 'Ashwini', '82', '43539', 'Dr. Neha', 'Male', '', '', 'obesity,anemia, diabities', 'Stage 2', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat122', 'Manjunath', '28', '43536', 'Dr. Sashwath', 'Male', '', '', 'hypertension', 'Stage 4', 'Chemotheraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat123', 'Bhavana', '78', '43556', 'Dr. Pranesh', 'Male', '', '', 'obesity', 'Stage 4', 'Radiation Theraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat124', 'Bhavani', '77', '43565', 'Dr. Sunil', 'Female', '', '', 'obesity,anemia, diabities', 'Stage 2', 'Surgery', 'pain in bones or joints, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints', 'Heart Attack'),
('Pat125', 'Chaithra', '50', '43582', 'Dr. Vinay', 'Male', '', '', 'hypertension', 'Stage 4', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat126', 'Deeksha', '80', '43557', 'Dr. Smitha', 'Male', '', '', 'obesity', 'Stage 4', 'Chemotheraphy', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat127', 'Divya', '22', '43514', 'Dr. Krishna', 'Male', '', '', 'anemia, pneumonia', 'Stage 2', 'Radiation Theraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat128', 'Fiza', '71', '43136', 'Dr. Archana', 'Female', '', '', '', '', '', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat129', 'Firdose', '34', '43471', 'Dr. Vijay', 'Male', '', 'smoking, poor nutrition', 'diabties, anemia', 'Stage 1', 'Surgery', 'swollen lymph, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat130', 'Girish', '10', '43499', 'Dr. Roopa', 'Male', '', 'smoking, alcohol, chewing tobacco', 'hypertension, hepatits', 'Stage 3', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat131', 'Gowri', '95', '43556', 'Dr. Akash', 'Male', '', 'smoking, alcohol, chewing tobacco, poor nutrition', 'pneumonia,hypertension', 'Stage 4', 'Chemotheraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat132', 'Harsha', '40', '43527', 'Dr. Yogesh', 'Female', '', 'chewing tobacco, weakened immune system, poor nutrition', 'heart related problem, hypertension', 'Stage 2', 'Radiation Theraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat133', 'Harshitha', '72', '43468', 'Dr. Harish', 'Male', '', 'smoking, comsuming alcohol, hpv infection, genetic syndrome', 'diabities', 'Stage 4', 'Chemotheraphy', 'pain in bones or joints, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat134', 'Hithesh', '82', '43498', 'Dr. Anand', 'Female', '', 'weakened immune system, poor nutrition', 'hypertension', 'Stage 1', 'Surgery', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat135', 'Indu', '20', '43254', 'Dr. Amrutha', 'Female', '', 'chewing tobacco, weakened immune system, poor nutrition, genetic syndrome', 'anemia', 'Stage 3', 'Chemotheraphy', 'bleeding, easy bruising, frequent infections, mouth ulcer,ÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat136', 'Indushree', '83', '43319', 'Dr. Venkatesh', 'Male', '', 'chewing tobacco, weakened immune system, smoking, consuming alcohol', 'obesity', 'Stage 4', 'Chemotheraphy', 'fatigue, weight loss, frequent infections, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat137', 'Janavi', '95', '43511', 'Dr. Sowmya', 'Male', '', 'smoking, hpv infection, genetic syndrome', 'chronic bronchitis', 'Stage 3', 'Chemotheraphy', 'pain in bones or joints, dizziness, fatigue, fever, loss of appetite, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat138', 'Jaanupriya', '35', '43490', 'Dr. Veena', 'Male', '', 'alcohol, poor nutrition,chronic facial sun exposure', 'hypertension, diabities', 'Stage 2', 'Radiation Theraphy', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat139', 'Karthik', '89', '43522', 'Dr. Suresh', 'Male', '', 'alcohol, hpv infection, poor nutrition', 'anemia, obesity', 'Stage 2', 'Radiation Theraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat140', 'Kavitha', '9', '43495', 'Dr. Ramesh', 'Female', '', 'hpv infection, poor nutrtion', 'pneumonia,diabities', 'Stage 1', 'Surgery', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat141', 'Dileep', '82', '43524', 'Dr. Neha', 'Male', '', 'smoking, consuming alcohol, genetic syndrome, ÿhpv infection', 'heart related problem, hypertension', 'Stage 4', 'Chemotheraphy', 'pain in bones or joints, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat142', 'Kavya', '53', '43527', 'Dr. Sashwath', 'Female', '', 'chewing tobacco, hpv infection, chronic facial sun exposure', 'pneumonia', 'Stage 3', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat143', 'Kiran', '83', '43560', 'Dr. Pranesh', 'Male', '', 'smoking', 'chronic bronchitis, obesity', 'Stage 1', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat144', 'Krupesh', '93', '43561', 'Dr. Sunil', 'Female', '', 'chewing tobacco, poor nutrition, genetic syndrome', 'obesity,anemia, diabities', 'Stage 2', 'Radiation Theraphy', 'bleeding, easy bruising, frequent infections, mouth ulcer,ÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat145', 'Kruthika', '9', '43558', 'Dr. Vinay', 'Male', '', 'chewing tobacco, weakened immune system, smoking, consuming alcohol, genetic syndrome', 'hypertension', 'Stage 4', 'Chemotheraphy', 'fatigue, weight loss, frequent infections, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat146', 'Kshithija', '71', '43521', 'Dr. Smitha', 'Male', '', 'consuming alcohol, smoking, hpv infection, genetic syndrome, chronic facial sun exposure', 'obesity', 'Stage 4', 'Chemotheraphy', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat147', 'Kulkarni', '54', '43530', 'Dr. Krishna', 'Male', '', 'smoking, consuming alcohol, hpv infection', 'anemia, pneumonia', 'Stage 2', 'Radiation Theraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Sleeping problems', 'Heart Attack'),
('Pat148', 'Lakshmi', '44', '43499', 'Dr. Archana', 'Female', '', 'chewing tobacco', 'diabities', 'Stage 1', 'Surgery', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat149', 'Madhu P', '17', '43469', 'Dr. Vijay', 'Male', '', 'smoking, poor nutrition', 'diabties, anemia', 'Stage 1', 'Surgery', 'pain in bones or joints, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat150', 'Mahesh', '14', '43496', 'Dr. Roopa', 'Male', '', 'smoking, poor nutrition', 'diabties, anemia', 'Stage 1', 'Surgery', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat151', 'Maheshwari', '36', '43491', 'Dr. Akash', 'Male', '', 'smoking, alcohol, chewing tobacco', 'hypertension, hepatits', 'Stage 3', 'Chemotheraphy', 'pain in bones or joints, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat152', 'Manoj', '81', '43510', 'Dr. Yogesh', 'Male', '', 'smoking, alcohol, chewing tobacco, poor nutrition', 'pneumonia,hypertension', 'Stage 4', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat153', 'Meera', '24', '43539', 'Dr. Harish', 'Female', '', 'chewing tobacco, weakened immune system, poor nutrition', 'heart related problem, hypertension', 'Stage 2', 'Radiation Theraphy', 'bleeding, easy bruising, frequent infections, mouth ulcer,ÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat154', 'Megha', '40', '43536', 'Dr. Anand', 'Male', '', 'smoking, comsuming alcohol, hpv infection, genetic syndrome', 'diabities', 'Stage 4', 'Chemotheraphy', 'fatigue, weight loss, frequent infections, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat155', 'Nagashree', '73', '43556', 'Dr. Amrutha', 'Female', '', 'weakened immune system, poor nutrition', 'hypertension', 'Stage 1', 'Surgery', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat156', 'Naziya', '17', '43565', 'Dr. Venkatesh', 'Female', '', 'chewing tobacco, weakened immune system, poor nutrition, genetic syndrome', 'anemia', 'Stage 3', 'Chemotheraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat157', 'Nithya', '68', '43582', 'Dr. Sowmya', 'Male', '', 'chewing tobacco, weakened immune system, smoking, consuming alcohol', 'obesity', 'Stage 4', 'Chemotheraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat158', 'Pavan', '66', '43557', 'Dr. Veena', 'Male', '', 'smoking, hpv infection, genetic syndrome', 'chronic bronchitis', 'Stage 3', 'Chemotheraphy', 'pain in bones or joints, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat159', 'Pavithra', '20', '43514', 'Dr. Suresh', 'Male', '', 'alcohol, poor nutrition,chronic facial sun exposure', 'hypertension, diabities', 'Stage 2', 'Radiation Theraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat160', 'Pooja', '90', '43136', 'Dr. Ramesh', 'Male', '', 'alcohol, hpv infection, poor nutrition', 'anemia, obesity', 'Stage 2', 'Radiation Theraphy', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat161', 'Poojashree', '27', '43471', 'Dr. Veena', 'Female', '', 'hpv infection, poor nutrtion', 'pneumonia,diabities', 'Stage 1', 'Surgery', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat162', 'Pradeep', '53', '43499', 'Dr. Suresh', 'Male', '', 'smoking, consuming alcohol, genetic syndrome, ÿhpv infection', 'heart related problem, hypertension', 'Stage 4', 'Chemotheraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat163', 'Prashanth', '87', '43556', 'Dr. Ramesh', 'Female', '', 'chewing tobacco, hpv infection, chronic facial sun exposure', 'pneumonia', 'Stage 3', 'Chemotheraphy', 'pain in bones or joints, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat164', 'Praveen', '60', '43527', 'Dr. Veena', 'Male', '', 'smoking', 'chronic bronchitis, obesity', 'Stage 1', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat165', 'Rakesh', '47', '43136', 'Dr. Suresh', 'Female', '', 'chewing tobacco, poor nutrition, genetic syndrome', 'obesity,anemia, diabities', 'Stage 2', 'Radiation Theraphy', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat166', 'Roshan', '44', '43471', 'Dr. Ramesh', 'Male', '', 'chewing tobacco, weakened immune system, smoking, consuming alcohol, genetic syndrome', 'hypertension', 'Stage 4', 'Chemotheraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat167', 'Rakshitha', '51', '43499', 'Dr. Veena', 'Male', '', 'consuming alcohol, smoking, hpv infection, genetic syndrome, chronic facial sun exposure', 'obesity', 'Stage 4', 'Chemotheraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat168', 'Rakshith', '70', '43556', 'Dr. Suresh', 'Male', '', 'smoking, consuming alcohol, hpv infection', 'anemia, pneumonia', 'Stage 2', 'Radiation Theraphy', 'pain in bones or joints, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat169', 'Ranjana', '22', '43527', 'Dr. Ramesh', 'Female', '', 'chewing tobacco', 'diabities', 'Stage 1', 'Surgery', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat170', 'Ragini', '32', '43528', 'Dr. Pranesh', 'Female', '', 'smoking, poor nutrition', 'diabties, anemia', 'Stage 1', 'Surgery', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat171', 'Rakshith', '70', '43529', 'Dr. Sunil', 'Male', '', 'smoking, alcohol, chewing tobacco', 'hypertension, hepatits', 'Stage 3', 'Chemotheraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat172', 'Ramya C H', '57', '43530', 'Dr. Vinay', 'Female', '', 'smoking, alcohol, chewing tobacco, poor nutrition', 'pneumonia,hypertension', 'Stage 4', 'Chemotheraphy', 'pain in bones or joints, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat173', 'Ravi Kumar S', '92', '43531', 'Dr. Smitha', 'Male', '', 'chewing tobacco, weakened immune system, poor nutrition', 'heart related problem, hypertension', 'Stage 2', 'Radiation Theraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat174', 'Ravikumar', '80', '43532', 'Dr. Krishna', 'Male', '', 'smoking, comsuming alcohol, hpv infection, genetic syndrome', 'diabities', 'Stage 4', 'Chemotheraphy', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat175', 'Reshma', '83', '43533', 'Dr. Archana', 'Female', '', 'weakened immune system, poor nutrition', 'hypertension', 'Stage 1', 'Surgery', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat176', 'Roshan', '10', '43534', 'Dr. Vijay', 'Male', '', 'chewing tobacco, weakened immune system, poor nutrition, genetic syndrome', 'anemia', 'Stage 3', 'Chemotheraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat177', 'Roshan L', '77', '43535', 'Dr. Roopa', 'Male', '', 'chewing tobacco, weakened immune system, smoking, consuming alcohol', 'obesity', 'Stage 4', 'Chemotheraphy', 'pain in bones or joints, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat178', 'Sachin', '78', '43536', 'Dr. Akash', 'Male', '', 'smoking, hpv infection, genetic syndrome', 'chronic bronchitis', 'Stage 3', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat179', 'Sahana', '48', '43537', 'Dr. Yogesh', 'Female', '', 'alcohol, poor nutrition,chronic facial sun exposure', 'hypertension, diabities', 'Stage 2', 'Radiation Theraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat180', 'Sahanadevi', '42', '43538', 'Dr. Pranesh', 'Female', '', 'alcohol, hpv infection, poor nutrition', 'anemia, obesity', 'Stage 2', 'Radiation Theraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat181', 'Shahid', '25', '43539', 'Dr. Sunil', 'Male', '', 'hpv infection, poor nutrtion', 'pneumonia,diabities', 'Stage 1', 'Surgery', 'pain in bones or joints, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat182', 'Sharath M P', '22', '43540', 'Dr. Vinay', 'Male', '', 'smoking, consuming alcohol, genetic syndrome, ÿhpv infection', 'heart related problem, hypertension', 'Stage 4', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat183', 'Shilpashree S', '15', '43541', 'Dr. Smitha', 'Female', '', 'chewing tobacco, hpv infection, chronic facial sun exposure', 'pneumonia', 'Stage 3', 'Chemotheraphy', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat184', 'Siddappa Byakod', '11', '43542', 'Dr. Krishna', 'Male', '', 'smoking', 'chronic bronchitis, obesity', 'Stage 1', 'Chemotheraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat185', 'Simran', '22', '43543', 'Dr. Archana', 'Female', '', 'chewing tobacco, poor nutrition, genetic syndrome', 'obesity,anemia, diabities', 'Stage 2', 'Radiation Theraphy', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat186', 'Srinivas', '61', '43544', 'Dr. Vijay', 'Male', '', 'chewing tobacco, weakened immune system, smoking, consuming alcohol, genetic syndrome', 'hypertension', 'Stage 4', 'Chemotheraphy', 'swollen lymph, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat187', 'Sumitra', '17', '43545', 'Dr. Roopa', 'Female', '', 'consuming alcohol, smoking, hpv infection, genetic syndrome, chronic facial sun exposure', 'obesity', 'Stage 4', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat188', 'Sundramma', '63', '43546', 'Dr. Akash', 'Female', '', 'smoking, consuming alcohol, hpv infection', 'anemia, pneumonia', 'Stage 2', 'Radiation Theraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat189', 'Supriya B.N', '14', '43547', 'Dr. Yogesh', 'Female', '', 'chewing tobacco', 'diabities', 'Stage 1', 'Surgery', 'weight loss, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat190', 'Swathi', '82', '43548', 'Dr. Pranesh', 'Female', '', '', 'obesity,anemia, diabities', 'Stage 2', 'Chemotheraphy', 'pain in bones or joints, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat191', 'Thejaswini', '82', '43549', 'Dr. Sunil', 'Female', '', '', 'hypertension', 'Stage 4', 'Chemotheraphy', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat192', 'Vijaya Lakshmi', '32', '43550', 'Dr. Vinay', 'Female', '', '', 'obesity', 'Stage 4', 'Radiation Theraphy', 'bleeding, easy bruising, frequent infections, mouth ulcer,ÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat193', 'Vinay Maadhu T', '19', '43551', 'Dr. Smitha', 'Male', '', '', 'obesity,anemia, diabities', 'Stage 2', 'Surgery', 'fatigue, weight loss, frequent infections, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat194', 'Vinutha', '23', '43552', 'Dr. Krishna', 'Female', '', '', 'hypertension', 'Stage 4', 'Chemotheraphy', 'pain in bones or joints, dizziness, fatigue, fever, loss of appetite, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat195', 'Vivek', '35', '43553', 'Dr. Archana', 'Male', '', '', 'obesity', 'Stage 4', 'Chemotheraphy', 'unintentional weight loss, weakness, frequent infections, easy bleeding, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat196', 'Vivek N', '65', '43554', 'Dr. Vijay', 'Male', '', '', 'anemia, pneumonia', 'Stage 2', 'Radiation Theraphy', 'nosebleed, pallor, red spots on skin, shortness of breath, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat197', 'Yashaswini N Prasad', '23', '43555', 'Dr. Roopa', 'Female', '', '', '', '', '', 'red spots on skin, shortness of breath, swollen lymphÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat198', 'Yashaswini T J', '22', '43556', 'Dr. Akash', 'Female', '', 'smoking, poor nutrition', 'diabties, anemia', 'Stage 1', 'Surgery', 'bleeding, easy bruising, frequent infections, mouth ulcer,ÿ, Fatigue, Shortness of breath, Bruising, Bleeding, Fever, Pains in bones and joints, Swollen lymph nodes', 'Heart Attack'),
('Pat199', 'Ashwini', '31', '43539', 'Dr. Yogesh', 'Female', 'pain,bleed from mouth, red and white patches,lymphnode enlargement, ulcers', 'smoking, alcohol, chewing tobacco', 'hypertension, hepatits', 'Stage 3', 'Chemotheraphy', 'Throat pain', 'Normal'),
('Pat200', 'Manjunath', '24', '43536', 'Dr. Sashwath', 'Male', 'pain,bleed from mouth, red and white patches,lymphnode enlargement, ulcers, sore thorat,difficulty in opening mouth', 'smoking, alcohol, chewing tobacco, poor nutrition', 'pneumonia,hypertension', 'Stage 4', 'Chemotheraphy', 'Back ache', 'Normal'),
('Pat201', 'Bhavana', '24', '43556', 'Dr. Pranesh', 'Female', 'loss of weight, ulcers, lump in neck, sweeling', 'chewing tobacco, weakened immune system, poor nutrition', 'heart related problem, hypertension', 'Stage 2', 'Radiation Theraphy', 'headache', 'Normal'),
('Pat202', 'Bhavani', '33', '43565', 'Dr. Sunil', 'Female', 'sore throat, ulcers, loose teeth, sweeling', 'smoking, comsuming alcohol, hpv infection, genetic syndrome', 'diabities', 'Stage 4', 'Chemotheraphy', 'Throat pain', 'Normal'),
('Pat203', 'Chaithra', '29', '43582', 'Dr. Vinay', 'Female', 'pain,bleed from mouth, red and white patches,lymphnode enlargement, ulcers', 'weakened immune system, poor nutrition', 'hypertension', 'Stage 1', 'Surgery', 'Throat pain', 'Normal'),
('Pat204', 'Deeksha', '38', '43557', 'Dr. Smitha', 'Female', 'pain,bleed from mouth, red and white patches,lymphnode enlargement, ulcers, sore thorat,difficulty in opening mouth', 'chewing tobacco, weakened immune system, poor nutrition, genetic syndrome', 'anemia', 'Stage 3', 'Chemotheraphy', 'Back ache', 'Normal'),
('Pat205', 'Divya', '21', '43514', 'Dr. Krishna', 'Female', 'loss of weight, ulcers, lump in neck, sweeling', 'chewing tobacco, weakened immune system, smoking, consuming alcohol', 'obesity', 'Stage 4', 'Chemotheraphy', 'headache', 'Normal'),
('w', 'w', 'w', '', 'w', '', 'w', 'w', 'w', 'Stage 2', 'w', 'w', 'Heart Failure'),
('w1', 'w', 'w', '', 'w', '', 'w', 'w', 'w', 'Normal', 'w', 'demo, demo, demo', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `userdata`
--

CREATE TABLE `userdata` (
  `Uid` varchar(50) NOT NULL,
  `Uname` varchar(80) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Pswd` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Addr` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdata`
--

INSERT INTO `userdata` (`Uid`, `Uname`, `Name`, `Pswd`, `Email`, `Phone`, `Addr`) VALUES
('User29770', 'chai', 'Chaithra', 'chai', 'chaithramrao.10@gmail.com', '9986842112', 'Belihalli , Koppa'),
('User20613', 'chethu', 'Chethan', 'chethu', 'chethu@gmail.com', '9880580370', 'Mysore'),
('User34049', 'swara', 'Swara', 'swara', 'swara@gmail.com', '9632347500', 'Mysore'),
('User70556', 'Madhu', 'Madhu', 'madhu', 'madhu@gmail.com', '9986452145', 'Sagara'),
('User55984', 'yashaswinidk', 'Yashaswini D K', '7975788y', 'yashaswini.0898@gmail.com', '7975788613', '#43 tpea layout sharadadevi nagar mysore');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hfdataset`
--
ALTER TABLE `hfdataset`
  ADD PRIMARY KEY (`Pid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
